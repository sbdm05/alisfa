<?php
/**
 * Template Name: Page par défaut

 */
get_header(); ?>


      <!-- Colonne principale -->
      <section class="colonne unique">
        <div id="main">
          <h1>Désolé, aucun contenu à cette adresse</h1>
          <h2><a href="<?php echo site_url(); ?>">Revenir à l'accueil</a>
        </div>
      </section><!-- Fin colonne principale -->
<!-- DECOUPE PHP - Fin du contenu principal - début de "inc_fermeture_page (container et bande)" -->
    </div><!-- Fin page -->
  </div><!-- Fin container -->
</div><!-- Fin bande -->

<?php get_footer(); ?>
